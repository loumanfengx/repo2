create view v1 as
select `smbms`.`smbms_user`.`id`           AS `id`,
       `smbms`.`smbms_user`.`userCode`     AS `userCode`,
       `smbms`.`smbms_user`.`userName`     AS `userName`,
       `smbms`.`smbms_user`.`userPassword` AS `userPassword`,
       `smbms`.`smbms_user`.`gender`       AS `gender`,
       `smbms`.`smbms_user`.`birthday`     AS `birthday`,
       `smbms`.`smbms_user`.`phone`        AS `phone`,
       `smbms`.`smbms_user`.`address`      AS `address`,
       `smbms`.`smbms_user`.`userRole`     AS `userRole`,
       `smbms`.`smbms_user`.`createdBy`    AS `createdBy`,
       `smbms`.`smbms_user`.`creationDate` AS `creationDate`,
       `smbms`.`smbms_user`.`modifyBy`     AS `modifyBy`,
       `smbms`.`smbms_user`.`modifyDate`   AS `modifyDate`
from `smbms`.`smbms_user`;

-- comment on column v1.id not supported: 主键ID

-- comment on column v1.userCode not supported: 用户编码

-- comment on column v1.userName not supported: 用户名称

-- comment on column v1.userPassword not supported: 用户密码

-- comment on column v1.gender not supported: 性别（1:女、 2:男）

-- comment on column v1.birthday not supported: 出生日期

-- comment on column v1.phone not supported: 手机

-- comment on column v1.address not supported: 地址

-- comment on column v1.userRole not supported: 用户角色（取自角色表-角色id）

-- comment on column v1.createdBy not supported: 创建者（userId）

-- comment on column v1.creationDate not supported: 创建时间

-- comment on column v1.modifyBy not supported: 更新者（userId）

-- comment on column v1.modifyDate not supported: 更新时间

